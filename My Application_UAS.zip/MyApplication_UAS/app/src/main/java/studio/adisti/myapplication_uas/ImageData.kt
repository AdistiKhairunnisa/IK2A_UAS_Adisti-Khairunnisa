package studio.adisti.myapplication_uas

data class ImageData (
    val imageUrl : String
)